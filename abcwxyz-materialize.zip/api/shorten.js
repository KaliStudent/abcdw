// Future implementation for /api/shorten
export default function handler(req, res) {
  res.status(200).json({ shortUrl: "https://abcw.xyz/demo" });
}
